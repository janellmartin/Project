//
//  CreatePatients.h
//  Emergency Room
//
//  Created by Janell Martin on 5/16/18.
//  Copyright © 2018 Janell Martin. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include "Patient.h"

#ifndef CreatePatients_h
#define CreatePatients_h

struct CreatePatients {
    //all people from 273ville
    std::map<int, Patient *> people;
    
    CreatePatients() {
        std::string name;
        std::ifstream patients;
        patients.open("/Users/janellmartin/Desktop/Data Structures"); //opening file
        
        std::vector<std::string> names;
        std::string newName;
        int num = 0;
        while(patients >> newName)
        {
            names.push_back(newName);
            num++;
        }
        
        for (int i = 0 ; i < num; i++){
            Patient *p = new Patient(names[i]);
            people.insert(std::make_pair(i, p));
        }
    }
    
};


#endif /* CreatePatients_h */
